public interface Position<E>{
	public E getElement(); 
	public void setElement(E newElement);
}